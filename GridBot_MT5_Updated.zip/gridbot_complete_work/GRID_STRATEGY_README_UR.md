# GridBot Strategy — MT5 Windows Bridge

## Strategy rules currently encoded in the Windows bridge
- Initial direction: compare MT5 mid-price over a rolling 10-second window. Positive movement => BUY; negative movement => SELL. No movement => wait.
- Initial order: 0.01 lot.
- After a basket has fully closed: 10-second cooldown window movement selects the next direction before the next 0.01 entry.
- Grid additions remain in the basket's original direction: 0.02, 0.03, 0.05 after configured adverse price steps.
- Basket target before the 0.05 level: +$1.
- Basket target once the 0.05 level is open: +$3.
- Emergency threshold: -$50, close the strategy's positions for the selected symbol and halt. Manual operator restart is required.

## Important implementation boundaries
- The Android app calls the Windows bridge over HTTPS. The Windows bridge uses the installed MetaTrader 5 terminal through the official Python `MetaTrader5` package. MetaApi has been removed.
- One bridge process controls one MT5 terminal/account and one symbol strategy at a time. To run Exness and Vantage simultaneously, use separate terminal installations and separate bridge instances/ports, or separate Windows VPS instances.
- The bridge is Demo-only by default. `ALLOW_LIVE_TRADING=false` must remain set until all Demo tests and risk checks pass.
- P/L currently sums MT5 position `profit + swap`; commissions are not fully reconciled from deal history. Therefore the -$50 check is not a guaranteed account-wide maximum-loss cap.
- `step_price` is symbol-price units. XAUUSD defaults to $1 in the Android client; Forex uses 10 pips. Other symbols are intentionally blocked until a broker-specific grid step is configured.
- Stop prevents further strategy actions but does not close open positions. Use the explicit close-all action from a secured operator endpoint/client and verify positions afterwards.
- The backend must be exposed only through HTTPS/private VPN with a strong random API key. Do not expose the raw Uvicorn port to the public internet.

## Files
- `mt5-windows-bridge/`: Windows MT5 service, API, strategy runner, and Demo-first setup.
- `app/`: Android UI and HTTPS client to the bridge.
