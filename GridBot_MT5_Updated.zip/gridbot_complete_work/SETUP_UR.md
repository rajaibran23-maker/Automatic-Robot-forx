# GridBot — آسان Setup (Urdu)

## پہلے کیا چاہیے؟
- Windows VPS (آن اور انٹرنیٹ سے منسلک)
- Exness یا Vantage کا MT5 Demo account
- Windows پر MT5 terminal اور Python 3.11 (64-bit)
- ایک domain جس کا HTTPS certificate درست ہو، یا محفوظ private VPN

## Windows VPS پر
1. مطلوبہ broker کا MT5 terminal install کریں۔
2. MT5 میں Demo account login کریں اور Market Watch میں `XAUUSD` دکھائیں۔ اگر آپ کے broker میں نام مختلف ہے تو وہ exact symbol name نوٹ کریں۔
3. `mt5-windows-bridge` folder VPS پر copy کریں۔
4. `run_windows.bat` چلائیں۔ پہلی بار `.env` بنے گی؛ اسے edit کریں:
   - `GRIDBOT_API_KEY` کو کم از کم 24 حروف کی نئی random secret سے بدلیں۔
   - `MT5_TERMINAL_PATH` کو اپنے `terminal64.exe` کے صحیح path سے بدلیں۔
   - `ALLOW_LIVE_TRADING=false` ہی رہنے دیں۔
5. Caddy یا کسی trusted HTTPS reverse proxy سے اپنے domain کو `127.0.0.1:8765` پر forward کریں۔ Raw port 8765 کو public internet پر نہ کھولیں۔
6. دوبارہ `run_windows.bat` چلائیں؛ `/health` پر `gridbot-mt5-windows-bridge` نظر آنا چاہیے۔

## Android APK میں
1. VPS screen میں domain، HTTPS port `443` اور وہی `GRIDBOT_API_KEY` ڈالیں۔
2. **Connect VPS** دبائیں۔
3. Broker screen میں Exness یا Vantage منتخب کریں، MT5 login، trading password اور MT5 میں دکھایا گیا exact Server name درج کریں۔
4. **Connect Broker** دبائیں۔ اصل Demo balance/equity ظاہر ہونا چاہیے۔
5. صرف ایک symbol enabled رکھیں۔ Gold کے لیے `XAUUSD` default ہے۔
6. **START** دبائیں۔ Server 10-second movement سے BUY/SELL منتخب کرے گا۔ فون بند ہونے کے بعد بھی VPS worker چلتا رہے گا، بشرطیکہ Windows VPS، MT5 terminal اور bridge چل رہے ہوں۔

## موجودہ پابندیاں
- یہ build Demo-only ہے؛ Live orders بند ہیں۔ `ALLOW_LIVE_TRADING=false` کو تبدیل نہ کریں۔
- ایک bridge instance ایک account اور ایک symbol چلاتا ہے۔ Exness اور Vantage بیک وقت چلانے کے لیے الگ MT5 terminal installations اور الگ bridge instances/HTTPS hostnames درکار ہیں۔
- MT5 account hedging mode میں ہونا ضروری ہے۔ Netting account پر Start رد ہوگا۔
- `$50` emergency check موجودہ open positions کے profit + swap پر ہے؛ commission reconciliation مکمل نہیں، اس لیے یہ guaranteed maximum-loss cap نہیں ہے۔
- Stop نئی trading روکتا ہے مگر کھلی positions خود بند نہیں کرتا۔ انہیں MT5 میں verify کریں؛ secured `/api/close-all` endpoint الگ موجود ہے۔
- اس ZIP میں source code ہے، تیار signed APK نہیں۔ GitHub Actions workflow یا Android Studio سے APK build کریں۔ اس ماحول میں Android Gradle build نہیں چلایا جا سکا۔
