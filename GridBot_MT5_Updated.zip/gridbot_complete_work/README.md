# GridBot Android + Windows MT5 Bridge

This project contains an Android control app and a Windows-only MT5 execution bridge. MetaApi has been removed. The Windows service uses the installed MetaTrader 5 desktop terminal and Python `MetaTrader5` package to authenticate, read quotes/positions, and send/close market orders.

## Architecture

`Android APK --HTTPS--> Windows VPS GridBot Bridge --> MetaTrader 5 terminal --> Exness OR Vantage MT5 account`

The Android app has a bridge API key field, checks bridge health, authenticates an Exness/Vantage MT5 account through the bridge, sends Demo-only start/stop commands, and polls live quotes, account values, and open positions while connected. The Windows bridge runs the strategy continuously, so the phone can be offline after the bot has been started.

## Build and test sequence
1. Follow `SETUP_UR.md` and `mt5-windows-bridge/README_UR.md` on a Windows VPS and connect an MT5 Demo account.
2. Put the bridge behind HTTPS and create a long random API key.
3. In the APK, enter the VPS hostname, HTTPS port (normally 443), and the bridge API key.
4. Connect the bridge, then enter the exact MT5 account login, trading password, and broker server name in the Broker screen. Choose Exness or Vantage.
5. Test the account balance and connection on Demo. Start is Demo-only by default.
6. Build the APK in Android Studio/compatible build environment after testing the project.

## Trading behavior
- First 0.01 order is selected from the direction of the 10-second price change.
- After a basket fully closes, 10-second cooldown window movement selects the next direction before the next basket.
- Grid levels: 0.01 / 0.02 / 0.03 / 0.05.
- Basket target: +$1 before the 0.05 level; +$3 once 0.05 is open.
- Emergency threshold: -$50 for the strategy's selected symbol, then halt.

## Safety and known limitations
- Live trading is blocked by default on both the APK request (`demo_only=true`) and bridge (`ALLOW_LIVE_TRADING=false`). The current APK is Demo-only; Live activation is a separate future change after Demo validation.
- The bridge controls one terminal/account and one symbol strategy per process. The APK requires exactly one enabled symbol per bridge session. Exness and Vantage can each have their own bridge instance and terminal installation; the app connects to one bridge endpoint at a time.
- The current -$50 check uses open position profit plus swap; commission/deal-history reconciliation is not complete, so it is not a guaranteed max-loss limit.
- MT5 hedging account mode is required. Netting accounts are rejected because the grid ladder requires distinct positions.
- Stop prevents new trades but does not automatically close existing positions.
- The APK and bridge source are provided, but this environment cannot authenticate to your private broker account or verify a broker execution. Android Gradle build was not run in this environment; use the included GitHub Actions workflow or Android Studio. Never treat this ZIP as proof that live trading has been tested.
