package com.example.network

import com.example.model.BrokerConfig
import com.example.model.BrokerType
import com.example.model.VpsConfig

class BrokerConnectionManager {
    suspend fun testAndConnectBroker(config: BrokerConfig, vps: VpsConfig): Result<BrokerConnectionResult> {
        if (config.brokerType == BrokerType.MT4 || config.brokerType == BrokerType.MT5) {
            return Result.failure(IllegalArgumentException("Select Exness MT5 or Vantage MT5."))
        }
        if (config.login.isBlank() || config.password.isBlank() || config.server.isBlank()) {
            return Result.failure(IllegalArgumentException("MT5 login, trading password and exact broker server are required."))
        }
        return try {
            val startedAt = System.nanoTime()
            val brokerName = if (config.brokerType == BrokerType.EXNESS) "EXNESS" else "VANTAGE"
            val response = Mt5BridgeClient(vps).connect(brokerName, config.login, config.password, config.server)
            val elapsedMs = ((System.nanoTime() - startedAt) / 1_000_000L).coerceAtLeast(1L)
            Result.success(
                BrokerConnectionResult(
                    isConnected = response.optBoolean("connected"),
                    pingMs = elapsedMs,
                    message = "${response.optString("broker")} MT5 authenticated (${response.optString("account_type")})",
                    balance = response.optDouble("balance"),
                    equity = response.optDouble("equity"),
                    currency = response.optString("currency", "USD"),
                    leverage = "1:${response.optInt("leverage", 0)}"
                )
            )
        } catch (e: Exception) {
            Result.failure(e)
        }
    }
}

data class BrokerConnectionResult(
    val isConnected: Boolean,
    val pingMs: Long,
    val message: String,
    val balance: Double,
    val equity: Double,
    val currency: String,
    val leverage: String
)
