package com.example.network

import com.example.model.VpsConfig
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.IOException
import java.util.concurrent.TimeUnit

/** HTTPS client for the user's Windows MT5 bridge. No broker password or API key is hard-coded. */
class Mt5BridgeClient(config: VpsConfig) {
    private val baseUrl: String
    private val apiKey = config.bridgeApiKey
    private val http = OkHttpClient.Builder()
        .connectTimeout(12, TimeUnit.SECONDS)
        .readTimeout(25, TimeUnit.SECONDS)
        .build()
    private val jsonType = "application/json; charset=utf-8".toMediaType()

    init {
        val host = config.ipAddress.trim().trimEnd('/')
        require(host.isNotBlank()) { "VPS host is required" }
        val candidate = if (host.startsWith("https://")) host else "https://$host:${config.port.trim()}"
        require(candidate.startsWith("https://")) { "Use HTTPS for the MT5 bridge" }
        require(apiKey.length >= 24) { "Enter the bridge API key from the Windows VPS .env file" }
        baseUrl = candidate
    }

    private suspend fun request(path: String, method: String = "GET", body: JSONObject? = null, auth: Boolean = true): JSONObject =
        withContext(Dispatchers.IO) {
            val builder = Request.Builder().url(baseUrl + path).header("Accept", "application/json")
            if (auth) builder.header("x-gridbot-key", apiKey)
            if (method == "POST") builder.post((body ?: JSONObject()).toString().toRequestBody(jsonType)) else builder.get()
            http.newCall(builder.build()).execute().use { response ->
                val raw = response.body?.string().orEmpty()
                if (!response.isSuccessful) throw IOException("MT5 bridge HTTP ${response.code}: $raw")
                if (raw.isBlank()) JSONObject() else JSONObject(raw)
            }
        }

    suspend fun health(): JSONObject = request("/health", auth = false)

    suspend fun connect(broker: String, login: String, password: String, server: String): JSONObject =
        request("/api/connect", "POST", JSONObject().apply {
            put("broker", broker)
            put("login", login.toLongOrNull() ?: throw IllegalArgumentException("MT5 login must be numeric"))
            put("password", password)
            put("server", server)
        })

    suspend fun status(): JSONObject = request("/api/status")
    suspend fun positions(): JSONArray = withContext(Dispatchers.IO) {
        val builder = Request.Builder().url(baseUrl + "/api/positions").header("Accept", "application/json").header("x-gridbot-key", apiKey).get()
        http.newCall(builder.build()).execute().use { response ->
            val raw = response.body?.string().orEmpty()
            if (!response.isSuccessful) throw IOException("MT5 bridge HTTP ${response.code}: $raw")
            JSONArray(raw)
        }
    }
    suspend fun quote(symbol: String): JSONObject = request("/api/quote/${symbol.replace("/", "")}")

    suspend fun start(symbol: String, stepPrice: Double): JSONObject =
        request("/api/start", "POST", JSONObject().apply {
            put("symbol", symbol)
            put("step_price", stepPrice)
            put("signal_min_move", 0.0)
            put("demo_only", true)
            put("live_confirmed", false)
        })

    suspend fun stop(): JSONObject = request("/api/stop", "POST")
    suspend fun closeAll(): JSONObject = request("/api/close-all", "POST")
    suspend fun disconnect(): JSONObject = request("/api/disconnect", "POST")
}
