# GridBot MT5 Windows Bridge (MetaApi کے بغیر)

یہ bridge Windows VPS پر MetaTrader 5 desktop terminal اور سرکاری Python `MetaTrader5` package استعمال کرتا ہے۔ Exness اور Vantage کے لیے MT5 terminal الگ الگ install کریں اور متعلقہ broker کا درست server name استعمال کریں۔ ایک bridge process ایک وقت میں ایک MT5 terminal/account چلاتا ہے؛ دونوں اکاؤنٹس بیک وقت چلانے کے لیے الگ Windows terminal installations اور الگ bridge instances/ports درکار ہیں۔

## اہم حدود
- یہ سروس Windows VPS پر چلتی ہے؛ Android/Termux/عام Linux PRoot پر `MetaTrader5` Python package نہیں چلتا۔
- APK میں HTTPS bridge client، Exness/Vantage account login، Demo-only Start/Stop، اور live quote/account/position polling شامل ہیں۔ اس ZIP کو پھر بھی اپنے Windows VPS اور Demo اکاؤنٹ پر integration-test کرنا ضروری ہے۔
- `ALLOW_LIVE_TRADING=false` default ہے۔ اسے تبدیل نہ کریں جب تک Demo testing، risk limits اور HTTPS/API authentication کی جانچ نہ ہو۔
- 10-second momentum کا مطلب ہر 10 سیکنڈ میں mid-price کا فرق ہے؛ صفر یا `signal_min_move` سے کم حرکت پر trade نہیں کھلے گی۔
- پہلے 0.01، پھر adverse grid distance پر 0.02، 0.03، 0.05؛ basket +$1 target (0.05 level سے پہلے)، 0.05 level کے بعد +$3؛ basket -$50 پر close-all اور halt۔
- MT5 position `profit + swap` استعمال ہوتا ہے۔ Broker commissions کا مکمل حساب الگ history/deal reconciliation کے بغیر شامل نہیں؛ اس لیے یہ -$50 حد حقیقی account-wide guaranteed loss cap نہیں ہے۔
- Stop endpoint نئے actions روکتا ہے، کھلی positions خود بخود بند نہیں کرتا۔ `/api/close-all` الگ action ہے۔

## Setup (Windows VPS)
1. Exness یا Vantage کی official MT5 terminal install کریں، login کرکے Market Watch میں مطلوبہ symbol دکھائیں۔
2. Python 3.11/3.12 x64 install کریں۔
3. اس folder میں `run_windows.bat` چلائیں؛ `.env` میں لمبی random `GRIDBOT_API_KEY` رکھیں۔
4. Windows Firewall میں 8765 کو public internet کے لیے کھلا نہ چھوڑیں۔ HTTPS reverse proxy/VPN یا private network استعمال کریں۔
5. `GET /health` health check ہے؛ `/api/*` کے لیے `x-gridbot-key` header لازم ہے۔

## API
- `POST /api/connect`: `{ "broker":"EXNESS", "login":123456, "password":"...", "server":"Exness-MT5Trial...", "terminal_path":"C:\\Program Files\\...\\terminal64.exe" }`
- `GET /api/status`
- `GET /api/quote/XAUUSD`
- `GET /api/positions`
- `POST /api/close-all` (robot کو روک کر صرف GridBot magic number والی positions بند کرتا ہے؛ response میں remaining positions verify کریں)
- `POST /api/start`: `{ "symbol":"XAUUSD", "step_price":1.0, "signal_min_move":0.0, "demo_only":true }`
- `POST /api/stop`
- `POST /api/close-all`
- `POST /api/disconnect`

`step_price` symbol کے price units میں ہے، broker کے contract کے مطابق خود طے کریں؛ غلط step grid کو غلط رفتار سے چلا سکتا ہے۔ `signal_min_move` بھی اسی price unit میں ہے۔

## Exness + Vantage
ایک ہی process میں دو terminal connections share نہیں کیے جاتے۔ Exness کے لیے ایک copy port 8765 پر، Vantage کے لیے دوسری copy port 8766 پر الگ `.env`/API key اور الگ terminal path کے ساتھ چلائیں۔ دونوں کی الگ VPS installations بہتر ہیں۔

## HTTPS reverse proxy (Caddy example)
`Caddyfile.example` mein `gridbot.example.com` ko apne domain se replace karein. Caddy ko public 443 par TLS terminate karne dein; Uvicorn sirf `127.0.0.1:8765` par bind hota hai. DNS A record VPS ke public IP par point hona chahiye. Firewall mein public side par sirf required HTTPS port kholain; 8765 ko public na kholain.
