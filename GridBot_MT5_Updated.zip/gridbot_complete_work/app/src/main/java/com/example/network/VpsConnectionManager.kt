package com.example.network

import com.example.model.EaFileItem
import com.example.model.FileExecutionStatus
import com.example.model.VpsConfig

class VpsConnectionManager {
    suspend fun testAndConnectVps(config: VpsConfig): Result<VpsConnectionResult> = try {
        val startedAt = System.nanoTime()
        val response = Mt5BridgeClient(config).health()
        val elapsedMs = ((System.nanoTime() - startedAt) / 1_000_000L).coerceAtLeast(1L)
        if (!response.optBoolean("ok") || response.optString("service") != "gridbot-mt5-windows-bridge") {
            Result.failure(IllegalStateException("The server responded, but GridBot MT5 Bridge was not found."))
        } else {
            Result.success(VpsConnectionResult(true, elapsedMs, "GridBot MT5 Windows Bridge is online", "Windows MT5 Bridge", false, "Configured on Windows VPS"))
        }
    } catch (e: Exception) {
        Result.failure(e)
    }

    suspend fun compileAndDeployEa(
        fileItem: EaFileItem,
        vpsConfig: VpsConfig,
        onProgress: (FileExecutionStatus, String) -> Unit
    ): Result<String> {
        val message = "EA file upload/MetaEditor compilation is not included in this bridge build. The built-in GridBot strategy runs inside the Windows bridge instead."
        onProgress(FileExecutionStatus.COMPILATION_ERROR, message)
        return Result.failure(UnsupportedOperationException(message))
    }
}

data class VpsConnectionResult(
    val isConnected: Boolean,
    val pingMs: Long,
    val message: String,
    val osInfo: String,
    val metaEditorReady: Boolean,
    val terminalPath: String
)
