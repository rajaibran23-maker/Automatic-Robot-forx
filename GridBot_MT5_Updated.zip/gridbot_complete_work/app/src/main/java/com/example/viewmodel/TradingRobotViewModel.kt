package com.example.viewmodel

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.engine.AutomatedTradingEngine
import com.example.model.ActiveTrade
import com.example.model.BrokerConfig
import com.example.model.BrokerType
import com.example.model.EaFileItem
import com.example.model.EaFileType
import com.example.model.FileExecutionStatus
import com.example.model.LogType
import com.example.model.SymbolCategory
import com.example.model.TradeLog
import com.example.model.TradingSymbol
import com.example.model.VpsConfig
import com.example.network.BrokerConnectionManager
import com.example.network.Mt5BridgeClient
import com.example.network.VpsConnectionManager
import com.example.security.SecureStorage
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import kotlinx.coroutines.launch

class TradingRobotViewModel(application: Application) : AndroidViewModel(application) {

    private val secureStorage = SecureStorage(application.applicationContext)
    private val brokerManager = BrokerConnectionManager()
    private val vpsManager = VpsConnectionManager()
    private val tradingEngine = AutomatedTradingEngine()
    private var marketPollJob: Job? = null

    // Current Navigation Page (1 to 6)
    // 0: Home Dashboard, 1: Broker Connection, 2: VPS Connection, 3: Robot Control, 4: Lot Size and Symbols, 5: File Manager
    private val _currentPage = MutableStateFlow(0)
    val currentPage: StateFlow<Int> = _currentPage.asStateFlow()

    // Broker Configuration & State
    private val _brokerConfig = MutableStateFlow(
        BrokerConfig(
            brokerType = BrokerType.EXNESS,
            login = secureStorage.getString("broker_login", ""),
            password = secureStorage.getSecure("broker_pwd", ""),
            server = secureStorage.getString("broker_server", "")
        )
    )
    val brokerConfig: StateFlow<BrokerConfig> = _brokerConfig.asStateFlow()

    private val _brokerIsConnecting = MutableStateFlow(false)
    val brokerIsConnecting: StateFlow<Boolean> = _brokerIsConnecting.asStateFlow()

    // VPS Configuration & State
    private val _vpsConfig = MutableStateFlow(
        VpsConfig(
            ipAddress = secureStorage.getString("vps_ip", ""),
            port = secureStorage.getString("vps_port", "443"),
            username = secureStorage.getString("vps_user", "Administrator"),
            password = secureStorage.getSecure("vps_pwd", ""),
            bridgeApiKey = secureStorage.getSecure("bridge_api_key", "")
        )
    )
    val vpsConfig: StateFlow<VpsConfig> = _vpsConfig.asStateFlow()

    private val _vpsIsConnecting = MutableStateFlow(false)
    val vpsIsConnecting: StateFlow<Boolean> = _vpsIsConnecting.asStateFlow()

    // Trading Symbols (The 7 strictly required symbols)
    private val _symbols = MutableStateFlow<List<TradingSymbol>>(
        listOf(
            TradingSymbol(
                id = "gold",
                displayName = "GOLD",
                code = "XAUUSD",
                category = SymbolCategory.COMMODITIES,
                isEnabled = secureStorage.getBoolean("sym_gold", true),
                bid = 0.0,
                ask = 0.0,
                spread = 0.0,
                digits = 2
            ),
            TradingSymbol(
                id = "bitcoin",
                displayName = "BITCOIN",
                code = "BTCUSD",
                category = SymbolCategory.CRYPTO,
                isEnabled = secureStorage.getBoolean("sym_bitcoin", false),
                bid = 0.0,
                ask = 0.0,
                spread = 0.0,
                digits = 2
            ),
            TradingSymbol(
                id = "oil",
                displayName = "OIL",
                code = "USOIL / UKOIL",
                category = SymbolCategory.COMMODITIES,
                isEnabled = secureStorage.getBoolean("sym_oil", false),
                bid = 0.0,
                ask = 0.0,
                spread = 0.0,
                digits = 2
            ),
            TradingSymbol(
                id = "audusd",
                displayName = "AUDUSD",
                code = "AUDUSD",
                category = SymbolCategory.FOREX,
                isEnabled = secureStorage.getBoolean("sym_audusd", false),
                bid = 0.0,
                ask = 0.0,
                spread = 0.0,
                digits = 5
            ),
            TradingSymbol(
                id = "audjpy",
                displayName = "AUDJPY",
                code = "AUDJPY",
                category = SymbolCategory.FOREX,
                isEnabled = secureStorage.getBoolean("sym_audjpy", false),
                bid = 0.0,
                ask = 0.0,
                spread = 0.0,
                digits = 3
            ),
            TradingSymbol(
                id = "audcad",
                displayName = "AUDCAD",
                code = "AUDCAD",
                category = SymbolCategory.FOREX,
                isEnabled = secureStorage.getBoolean("sym_audcad", false),
                bid = 0.0,
                ask = 0.0,
                spread = 0.0,
                digits = 5
            ),
            TradingSymbol(
                id = "audnzd",
                displayName = "AUDNZD",
                code = "AUDNZD",
                category = SymbolCategory.FOREX,
                isEnabled = secureStorage.getBoolean("sym_audnzd", false),
                bid = 0.0,
                ask = 0.0,
                spread = 0.0,
                digits = 5
            )
        )
    )
    val symbols: StateFlow<List<TradingSymbol>> = _symbols.asStateFlow()

    // Engine delegated state
    val isRobotOn: StateFlow<Boolean> = tradingEngine.isRobotOn
    val lotSize: StateFlow<Float> = tradingEngine.lotSize
    val logs: StateFlow<List<TradeLog>> = tradingEngine.logs
    val activeTrades: StateFlow<List<ActiveTrade>> = tradingEngine.activeTrades
    val totalProfit: StateFlow<Double> = tradingEngine.totalProfit

    // File Manager State
    private val _filesList = MutableStateFlow<List<EaFileItem>>(
        listOf(
            EaFileItem(
                id = "ea_1",
                fileName = "GoldScalper_Pro_v4.mq4",
                fileType = EaFileType.MQ4,
                fileSizeFormatted = "48.2 KB",
                isRequiresCompilation = true,
                status = FileExecutionStatus.IDLE,
                statusDetails = "MQL4 source code. Requires MetaEditor compilation on VPS.",
                isBundledTemplate = true
            ),
            EaFileItem(
                id = "ea_2",
                fileName = "TrendMaster_MT5_HighSpeed.ex5",
                fileType = EaFileType.EX5,
                fileSizeFormatted = "182.5 KB",
                isRequiresCompilation = false,
                status = FileExecutionStatus.IDLE,
                statusDetails = "MT5 pre-compiled binary. Ready to run on VPS terminal.",
                isBundledTemplate = true
            ),
            EaFileItem(
                id = "ea_3",
                fileName = "Exness_GridMaster_Multi.mq5",
                fileType = EaFileType.MQ5,
                fileSizeFormatted = "64.1 KB",
                isRequiresCompilation = true,
                status = FileExecutionStatus.IDLE,
                statusDetails = "MQL5 source code. Compiles via MetaEditor64 on VPS.",
                isBundledTemplate = true
            ),
            EaFileItem(
                id = "ea_4",
                fileName = "Oil_Scalper_Breakout.ex4",
                fileType = EaFileType.EX4,
                fileSizeFormatted = "112.0 KB",
                isRequiresCompilation = false,
                status = FileExecutionStatus.IDLE,
                statusDetails = "MT4 pre-compiled binary. Ready for VPS terminal execution.",
                isBundledTemplate = true
            )
        )
    )
    val filesList: StateFlow<List<EaFileItem>> = _filesList.asStateFlow()

    private val _selectedFile = MutableStateFlow<EaFileItem?>(_filesList.value.firstOrNull())
    val selectedFile: StateFlow<EaFileItem?> = _selectedFile.asStateFlow()

    private val _fileOperationInProgress = MutableStateFlow(false)
    val fileOperationInProgress: StateFlow<Boolean> = _fileOperationInProgress.asStateFlow()

    private val _alertMessage = MutableStateFlow<String?>(null)
    val alertMessage: StateFlow<String?> = _alertMessage.asStateFlow()

    init {
        // Restore stored lot size (default 0.05)
        val savedLot = secureStorage.getFloat("robot_lot_size", 0.05f)
        tradingEngine.setLotSize(savedLot)

        // No fabricated quote feed: prices remain placeholders until a verified market-data adapter is connected.
    }

    fun selectPage(index: Int) {
        _currentPage.value = index
    }

    fun clearAlert() {
        _alertMessage.value = null
    }

    // --- Broker Functions ---
    fun updateBrokerType(type: BrokerType) {
        _brokerConfig.update {
            it.copy(
                brokerType = type,
                server = when (type) {
                    BrokerType.EXNESS, BrokerType.VANTAGE -> ""
                    BrokerType.MT5, BrokerType.MT4 -> ""
                }
            )
        }
    }

    fun updateBrokerLogin(login: String) {
        _brokerConfig.update { it.copy(login = login) }
        secureStorage.saveString("broker_login", login)
    }

    fun updateBrokerPassword(pwd: String) {
        _brokerConfig.update { it.copy(password = pwd) }
        secureStorage.saveSecure("broker_pwd", pwd)
    }

    fun updateBrokerServer(server: String) {
        _brokerConfig.update { it.copy(server = server) }
        secureStorage.saveString("broker_server", server)
    }

    fun connectBroker() {
        val current = _brokerConfig.value
        viewModelScope.launch {
            _brokerIsConnecting.value = true
            tradingEngine.addLog("Connecting to ${current.brokerType.title} server: ${current.server}...", LogType.INFO)
            val result = brokerManager.testAndConnectBroker(current, _vpsConfig.value)
            _brokerIsConnecting.value = false

            result.fold(
                onSuccess = { res ->
                    _brokerConfig.update {
                        it.copy(
                            isConnected = true,
                            connectionMessage = res.message,
                            pingMs = res.pingMs,
                            balance = res.balance,
                            equity = res.equity,
                            currency = res.currency,
                            leverage = res.leverage
                        )
                    }
                    tradingEngine.addLog("Broker Connected: ${res.message}", LogType.SUCCESS)
                    startRemoteMonitoring()
                },
                onFailure = { err ->
                    _brokerConfig.update {
                        it.copy(
                            isConnected = false,
                            connectionMessage = err.localizedMessage ?: "Connection failed",
                            pingMs = 0
                        )
                    }
                    tradingEngine.addLog("Broker Connection Failed: ${err.localizedMessage}", LogType.ERROR)
                    _alertMessage.value = err.localizedMessage ?: "Broker connection failed"
                }
            )
        }
    }

    fun disconnectBroker() {
        val wasRunning = tradingEngine.isRobotOn.value
        val vps = _vpsConfig.value
        viewModelScope.launch {
            try {
                val client = Mt5BridgeClient(vps)
                if (wasRunning) {
                    client.stop()
                    marketPollJob?.cancel(); marketPollJob = null
                    tradingEngine.markRemoteStopped("Server robot stopped before broker disconnect.")
                }
                client.disconnect()
            } catch (e: Exception) {
                tradingEngine.addLog("Remote disconnect notice: ${e.localizedMessage}", LogType.WARNING)
            }
        }
        marketPollJob?.cancel(); marketPollJob = null
        tradingEngine.updateRemotePositions(org.json.JSONArray())
        _brokerConfig.update { it.copy(isConnected = false, connectionMessage = "Disconnected", pingMs = 0) }
        tradingEngine.addLog("Broker disconnect requested.", LogType.WARNING)
    }

    // --- VPS Functions ---
    fun updateVpsIp(ip: String) {
        _vpsConfig.update { it.copy(ipAddress = ip) }
        secureStorage.saveString("vps_ip", ip)
    }

    fun updateVpsPort(port: String) {
        _vpsConfig.update { it.copy(port = port) }
        secureStorage.saveString("vps_port", port)
    }

    fun updateVpsUsername(user: String) {
        _vpsConfig.update { it.copy(username = user) }
        secureStorage.saveString("vps_user", user)
    }

    fun updateVpsPassword(pwd: String) {
        _vpsConfig.update { it.copy(password = pwd) }
        secureStorage.saveSecure("vps_pwd", pwd)
    }

    fun updateVpsApiKey(key: String) {
        _vpsConfig.update { it.copy(bridgeApiKey = key) }
        secureStorage.saveSecure("bridge_api_key", key)
    }

    fun connectVps() {
        val current = _vpsConfig.value
        viewModelScope.launch {
            _vpsIsConnecting.value = true
            tradingEngine.addLog("Checking GridBot MT5 HTTPS bridge at ${current.ipAddress}:${current.port}...", LogType.INFO)
            val result = vpsManager.testAndConnectVps(current)
            _vpsIsConnecting.value = false

            result.fold(
                onSuccess = { res ->
                    _vpsConfig.update {
                        it.copy(
                            isConnected = true,
                            connectionMessage = res.message,
                            pingMs = res.pingMs,
                            osInfo = res.osInfo,
                            metaEditorReady = res.metaEditorReady,
                            activeTerminalPath = res.terminalPath
                        )
                    }
                    tradingEngine.addLog("Server Connected: ${res.message}. MT5 account login is a separate step.", LogType.SUCCESS)
                    if (_brokerConfig.value.isConnected) startRemoteMonitoring()
                },
                onFailure = { err ->
                    _vpsConfig.update {
                        it.copy(
                            isConnected = false,
                            connectionMessage = err.localizedMessage ?: "VPS unreachable",
                            pingMs = 0
                        )
                    }
                    tradingEngine.addLog("VPS Connection Error: ${err.localizedMessage}", LogType.ERROR)
                    _alertMessage.value = err.localizedMessage ?: "VPS connection failed"
                }
            )
        }
    }

    fun disconnectVps() {
        marketPollJob?.cancel(); marketPollJob = null
        _vpsConfig.update {
            it.copy(
                isConnected = false,
                connectionMessage = "VPS Disconnected",
                pingMs = 0
            )
        }
        if (tradingEngine.isRobotOn.value) {
            stopRobot()
        }
        tradingEngine.addLog("VPS Disconnected by user.", LogType.WARNING)
    }

    // --- Robot ON/OFF ---
    fun toggleRobot(on: Boolean) {
        if (on) {
            startRobot()
        } else {
            stopRobot()
        }
    }

    fun startRobot() {
        val broker = _brokerConfig.value
        val vps = _vpsConfig.value
        val enabledSymbols = _symbols.value.filter { it.isEnabled }
        val symbol = enabledSymbols.singleOrNull()
        if (!broker.isConnected) { _alertMessage.value = "Connect Exness/Vantage MT5 first."; return }
        if (!vps.isConnected) { _alertMessage.value = "Connect the Windows MT5 bridge first."; return }
        if (symbol == null) { _alertMessage.value = "Enable exactly one trading symbol. This bridge instance runs one symbol strategy at a time."; return }
        val stepPrice = when {
            symbol.code.equals("XAUUSD", true) -> 1.0
            symbol.category == SymbolCategory.FOREX -> com.example.engine.GridBasketStrategy.forexStepPrice(symbol.code, symbol.digits)
            else -> { _alertMessage.value = "Grid step for ${symbol.code} must be configured on the server before trading."; return }
        }
        viewModelScope.launch {
            try {
                val client = Mt5BridgeClient(vps)
                val response = client.start(symbol.code, stepPrice)
                tradingEngine.markRemoteStarted("Server robot started in ${response.optString("mode")} mode for ${symbol.code}. 10-second momentum enabled.")
                startRemoteMonitoring()
            } catch (e: Exception) {
                _alertMessage.value = e.localizedMessage ?: "Could not start server robot"
                tradingEngine.addLog("Server start failed: ${e.localizedMessage}", LogType.ERROR)
            }
        }
    }

    private fun startRemoteMonitoring() {
        val vps = _vpsConfig.value
        val symbol = _symbols.value.singleOrNull { it.isEnabled } ?: return
        if (!vps.isConnected || !vps.bridgeApiKey.isNotBlank()) return
        marketPollJob?.cancel()
        marketPollJob = viewModelScope.launch {
            val client = try { Mt5BridgeClient(vps) } catch (e: Exception) {
                tradingEngine.addLog("Bridge monitor setup failed: ${e.localizedMessage}", LogType.ERROR)
                return@launch
            }
            var statusCounter = 0
            while (_brokerConfig.value.isConnected && _vpsConfig.value.isConnected) {
                try {
                    val quote = client.quote(symbol.code)
                    val bid = quote.optDouble("bid")
                    val ask = quote.optDouble("ask")
                    _symbols.update { list -> list.map { item ->
                        if (item.code.equals(symbol.code, true)) item.copy(bid = bid, ask = ask, spread = ask - bid) else item
                    } }
                    tradingEngine.updateRemotePositions(client.positions())
                    statusCounter++
                    if (statusCounter % 5 == 0) {
                        val account = client.status()
                        _brokerConfig.update { it.copy(balance = account.optDouble("balance", it.balance), equity = account.optDouble("equity", it.equity)) }
                        val remoteBot = account.optJSONObject("bot")
                        if (remoteBot != null && !remoteBot.optBoolean("running", true) && tradingEngine.isRobotOn.value) {
                            tradingEngine.markRemoteStopped("Server robot stopped: ${remoteBot.optString("message")}")
                        }
                    }
                } catch (e: Exception) {
                    tradingEngine.addLog("Live market/account refresh failed: ${e.localizedMessage}", LogType.WARNING)
                }
                delay(1000)
            }
        }
    }

    fun stopRobot() {
        val vps = _vpsConfig.value
        viewModelScope.launch {
            try {
                val response = Mt5BridgeClient(vps).stop()
                tradingEngine.markRemoteStopped("Server robot stopped. ${response.optString("note")}")
            } catch (e: Exception) {
                _alertMessage.value = e.localizedMessage ?: "Could not stop server robot"
                tradingEngine.addLog("Server stop failed: ${e.localizedMessage}", LogType.ERROR)
            }
        }
    }

    // --- Lot Size ---
    fun updateLotSize(newLot: Float) {
        tradingEngine.setLotSize(newLot)
        secureStorage.saveFloat("robot_lot_size", tradingEngine.lotSize.value)
    }

    fun incrementLotSize(delta: Float) {
        val current = tradingEngine.lotSize.value
        val next = (current + delta).coerceIn(0.01f, 100.0f)
        updateLotSize(next)
    }

    // --- Trading Symbols ---
    fun toggleSymbol(symbolId: String, enabled: Boolean) {
        _symbols.update { list ->
            list.map { sym ->
                if (sym.id == symbolId) {
                    secureStorage.saveBoolean("sym_${sym.id}", enabled)
                    sym.copy(isEnabled = enabled)
                } else sym
            }
        }
        tradingEngine.addLog("Trading symbol updated: $symbolId -> ${if (enabled) "ENABLED" else "DISABLED"}", LogType.INFO)
    }

    // --- File Manager ---
    fun selectFile(fileItem: EaFileItem) {
        _selectedFile.value = fileItem
    }

    fun addCustomFile(name: String, sizeBytes: Long, content: String = "") {
        val ext = name.substringAfterLast(".", "").lowercase()
        val fileType = when (ext) {
            "mq4" -> EaFileType.MQ4
            "ex4" -> EaFileType.EX4
            "mq5" -> EaFileType.MQ5
            "ex5" -> EaFileType.EX5
            else -> {
                _alertMessage.value = "Unsupported file type '.$ext'. Only MT4 (.ex4, .mq4) and MT5 (.ex5, .mq5) files are supported."
                return
            }
        }

        val requiresComp = fileType == EaFileType.MQ4 || fileType == EaFileType.MQ5
        val sizeFormatted = String.format("%.1f KB", (sizeBytes.coerceAtLeast(1024) / 1024.0))

        val newFile = EaFileItem(
            id = "custom_${System.currentTimeMillis()}",
            fileName = name,
            fileType = fileType,
            fileSizeFormatted = sizeFormatted,
            isRequiresCompilation = requiresComp,
            status = FileExecutionStatus.IDLE,
            statusDetails = if (requiresComp) "MQL source code selected. Ready to compile via VPS MetaEditor." else "Pre-compiled EA binary selected. Ready for VPS deployment.",
            isBundledTemplate = false,
            sourceCode = content
        )

        _filesList.update { listOf(newFile) + it }
        _selectedFile.value = newFile
        tradingEngine.addLog("Selected EA file: $name ($fileType)", LogType.INFO)
    }

    fun runFile(fileItem: EaFileItem) {
        val vps = _vpsConfig.value
        if (!vps.isConnected) {
            val msg = "MetaTrader Expert Advisors (.ex4/.mq4/.ex5/.mq5) require a Windows/Wine MetaTrader environment and cannot run directly on Android OS. Please connect your VPS to compile and run this file."
            _alertMessage.value = msg
            updateFileStatus(fileItem.id, FileExecutionStatus.COMPILATION_ERROR, msg)
            tradingEngine.addLog("Execution Rejected: VPS connection required to run EA binaries.", LogType.ERROR)
            return
        }

        viewModelScope.launch {
            _fileOperationInProgress.value = true
            tradingEngine.addLog("Initiating remote EA deployment for '${fileItem.fileName}'...", LogType.INFO)
            
            vpsManager.compileAndDeployEa(
                fileItem = fileItem,
                vpsConfig = vps,
                onProgress = { status, detail ->
                    updateFileStatus(fileItem.id, status, detail)
                    tradingEngine.addLog("[VPS Terminal] ${fileItem.fileName}: $detail", when (status) {
                        FileExecutionStatus.RUNNING -> LogType.SUCCESS
                        FileExecutionStatus.COMPILATION_ERROR -> LogType.ERROR
                        else -> LogType.INFO
                    })
                }
            )
            _fileOperationInProgress.value = false
        }
    }

    fun stopFile(fileItem: EaFileItem) {
        updateFileStatus(fileItem.id, FileExecutionStatus.STOPPED, "EA execution halted on VPS terminal.")
        tradingEngine.addLog("Stopped '${fileItem.fileName}' on VPS.", LogType.WARNING)
    }

    private fun updateFileStatus(fileId: String, status: FileExecutionStatus, details: String) {
        _filesList.update { list ->
            list.map { f ->
                if (f.id == fileId) {
                    val updated = f.copy(status = status, statusDetails = details)
                    if (_selectedFile.value?.id == fileId) {
                        _selectedFile.value = updated
                    }
                    updated
                } else f
            }
        }
    }

}
