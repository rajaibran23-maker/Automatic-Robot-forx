package com.example.engine

import com.example.model.ActiveTrade
import com.example.model.LogType
import com.example.model.TradeLog
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONArray

class AutomatedTradingEngine {

    private val _isRobotOn = MutableStateFlow(false)
    val isRobotOn: StateFlow<Boolean> = _isRobotOn.asStateFlow()

    private val _lotSize = MutableStateFlow(0.05f)
    val lotSize: StateFlow<Float> = _lotSize.asStateFlow()

    private val _logs = MutableStateFlow<List<TradeLog>>(emptyList())
    val logs: StateFlow<List<TradeLog>> = _logs.asStateFlow()

    private val _activeTrades = MutableStateFlow<List<ActiveTrade>>(emptyList())
    val activeTrades: StateFlow<List<ActiveTrade>> = _activeTrades.asStateFlow()

    private val _totalProfit = MutableStateFlow(0.0)
    val totalProfit: StateFlow<Double> = _totalProfit.asStateFlow()

    fun setLotSize(size: Float) {
        val cleanSize = (Math.round(size * 100.0) / 100.0).toFloat().coerceIn(0.01f, 100.0f)
        _lotSize.value = cleanSize
        addLog("Updated lot size to $cleanSize", LogType.INFO)
    }

    fun updateRemotePositions(rows: JSONArray) {
        val parsed = buildList {
            for (i in 0 until rows.length()) {
                val item = rows.optJSONObject(i) ?: continue
                add(ActiveTrade(
                    ticket = item.optLong("ticket"),
                    symbol = item.optString("symbol"),
                    type = item.optString("side"),
                    lots = item.optDouble("volume"),
                    openPrice = item.optDouble("price_open"),
                    currentPrice = item.optDouble("price_current"),
                    stopLoss = 0.0,
                    takeProfit = 0.0,
                    profit = item.optDouble("profit") + item.optDouble("swap")
                ))
            }
        }
        _activeTrades.value = parsed
        _totalProfit.value = parsed.sumOf { it.profit }
    }

    fun markRemoteStarted(message: String) {
        _isRobotOn.value = true
        addLog(message, LogType.SUCCESS)
    }

    fun markRemoteStopped(message: String) {
        _isRobotOn.value = false
        addLog(message, LogType.WARNING)
    }

    fun addLog(message: String, type: LogType = LogType.INFO) {
        val log = TradeLog(message = message, type = type)
        _logs.update { (listOf(log) + it).take(100) }
    }
}
