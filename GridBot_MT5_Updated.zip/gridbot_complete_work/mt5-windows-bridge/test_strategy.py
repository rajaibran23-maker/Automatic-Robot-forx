import unittest
from types import SimpleNamespace
from strategy import GridState, momentum_side

class StrategyTests(unittest.TestCase):
    def test_ten_second_momentum_direction(self):
        self.assertEqual(momentum_side(0.5), "BUY")
        self.assertEqual(momentum_side(-0.5), "SELL")
        self.assertIsNone(momentum_side(0.0))
        self.assertIsNone(momentum_side(0.01, 0.02))

    def test_emergency_stop_latches(self):
        s = GridState(1.0)
        p = [SimpleNamespace(volume=0.01, price_open=100.0)]
        d = s.decide("BUY", 99.0, 99.1, p, -50.0)
        self.assertEqual(d.action, "CLOSE_ALL")
        self.assertTrue(s.halted)
        self.assertEqual(s.decide("BUY", 99, 99.1, [], 0).action, "HOLD")

    def test_first_target_before_final_lot(self):
        s = GridState(1.0)
        p = [SimpleNamespace(volume=0.01, price_open=100.0)]
        self.assertEqual(s.decide("BUY", 100, 100.1, p, 1.0).action, "CLOSE_ALL")

    def test_final_target_after_005_level(self):
        s = GridState(1.0)
        p = [SimpleNamespace(volume=v, price_open=100.0) for v in (0.01, 0.02, 0.03, 0.05)]
        self.assertEqual(s.decide("BUY", 100, 100.1, p, 2.0).action, "HOLD")
        self.assertEqual(s.decide("BUY", 100, 100.1, p, 3.0).action, "CLOSE_ALL")

    def test_grid_ladder(self):
        s = GridState(1.0)
        s.side = "BUY"
        s.last_entry = 100.0
        p = [SimpleNamespace(volume=0.01, price_open=100.0)]
        d = s.decide("BUY", 99.0, 99.1, p, 0.0)
        self.assertEqual((d.action, d.volume), ("OPEN", 0.02))

if __name__ == "__main__": unittest.main()
