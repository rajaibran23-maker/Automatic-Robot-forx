import os, time, threading, secrets, logging
from typing import Optional
from fastapi import FastAPI, Header, HTTPException, Depends
from pydantic import BaseModel, Field
import MetaTrader5 as mt5
from strategy import GridState, LOTS, momentum_side

logging.basicConfig(level=logging.INFO, format="%(asctime)s %(levelname)s %(message)s")
log = logging.getLogger("gridbot")
API_KEY = os.getenv("GRIDBOT_API_KEY", "")
ALLOW_LIVE = os.getenv("ALLOW_LIVE_TRADING", "false").lower() == "true"
REQUIRE_LIVE_CONFIRMATION = os.getenv("REQUIRE_LIVE_CONFIRMATION", "true").lower() == "true"
if len(API_KEY) < 24 or API_KEY.startswith("CHANGE_"):
    raise RuntimeError("Set GRIDBOT_API_KEY to a random secret of at least 24 characters")

app = FastAPI(title="GridBot MT5 Windows Bridge", version="1.0.0", docs_url=None, redoc_url=None, openapi_url=None)
lock = threading.RLock()
worker = None
stop_event = threading.Event()
connected = False
profile = {}
last_error = None
bot_state = {"running": False, "mode": "OFF", "last_signal": None, "last_action": None, "message": "Not started"}

def auth(x_gridbot_key: str = Header(default="")):
    if not secrets.compare_digest(x_gridbot_key, API_KEY):
        raise HTTPException(401, "Unauthorized")

def mt5_ready():
    if not connected:
        raise HTTPException(409, "MT5 is not connected. Call /api/connect first.")

def account_snapshot():
    info = mt5.account_info()
    if info is None:
        raise RuntimeError(f"MT5 account_info failed: {mt5.last_error()}")
    return info

class ConnectRequest(BaseModel):
    broker: str = Field(pattern="^(EXNESS|VANTAGE)$")
    login: int
    password: str = Field(min_length=1)
    server: str = Field(min_length=2)
    terminal_path: str = Field(default_factory=lambda: os.getenv("MT5_TERMINAL_PATH", ""), description="Full path to terminal64.exe on Windows VPS; can be set in .env")

class StartRequest(BaseModel):
    symbol: str = Field(min_length=3, max_length=32)
    step_price: float = Field(gt=0, description="Grid step in symbol price units; set from broker contract")
    signal_min_move: float = Field(default=0.0, ge=0, description="Minimum absolute price change over 10 seconds")
    demo_only: bool = True
    live_confirmed: bool = False

@app.get("/health")
def health():
    return {"ok": True, "service": "gridbot-mt5-windows-bridge", "connected": connected,
            "bot_running": bot_state["running"], "live_trading_allowed": ALLOW_LIVE}

@app.post("/api/connect", dependencies=[Depends(auth)])
def connect(req: ConnectRequest):
    global connected, profile, last_error
    if not req.terminal_path or len(req.terminal_path) < 3:
        raise HTTPException(400, "Set MT5_TERMINAL_PATH in the Windows VPS .env file or provide terminal_path")
    with lock:
        if bot_state["running"] or (worker is not None and worker.is_alive()):
            raise HTTPException(409, "Stop the robot and wait for its worker to exit before changing broker account")
        if connected:
            mt5.shutdown(); connected = False
        ok = mt5.initialize(path=req.terminal_path, login=req.login, password=req.password,
                            server=req.server, timeout=30000)
        if not ok:
            last_error = str(mt5.last_error())
            raise HTTPException(502, f"MT5 initialize/login failed: {last_error}")
        info = account_snapshot()
        profile = {"broker": req.broker, "login": int(info.login), "server": info.server,
                   "terminal_path": req.terminal_path}
        connected = True; last_error = None
        mode = int(getattr(info, "trade_mode", -1))
        return {"connected": True, "broker": req.broker, "login": int(info.login),
                "server": info.server, "trade_mode": mode,
                "account_type": "DEMO" if mode == 0 else ("CONTEST" if mode == 1 else "REAL"),
                "balance": float(info.balance), "equity": float(info.equity),
                "currency": info.currency, "leverage": int(info.leverage),
                "margin_mode": int(info.margin_mode)}

@app.get("/api/status", dependencies=[Depends(auth)])
def status():
    mt5_ready()
    with lock:
        info = account_snapshot()
        return {"connected": True, "profile": profile, "balance": float(info.balance),
                "equity": float(info.equity), "currency": info.currency,
                "trade_allowed": bool(info.trade_allowed), "bot": bot_state,
                "last_error": last_error}

@app.get("/api/quote/{symbol}", dependencies=[Depends(auth)])
def quote(symbol: str):
    mt5_ready()
    with lock:
        tick = mt5.symbol_info_tick(symbol)
        if tick is None:
            raise HTTPException(404, f"No tick for {symbol}: {mt5.last_error()}")
        return {"symbol": symbol, "bid": float(tick.bid), "ask": float(tick.ask),
                "time_msc": int(tick.time_msc)}

@app.get("/api/positions", dependencies=[Depends(auth)])
def positions(symbol: Optional[str] = None):
    mt5_ready()
    with lock:
        rows = mt5.positions_get(symbol=symbol) if symbol else mt5.positions_get()
        if rows is None:
            raise HTTPException(502, f"MT5 positions_get failed: {mt5.last_error()}")
        return [{"ticket": int(p.ticket), "symbol": p.symbol,
                 "side": "BUY" if p.type == mt5.POSITION_TYPE_BUY else "SELL",
                 "volume": float(p.volume), "price_open": float(p.price_open),
                 "price_current": float(p.price_current), "profit": float(p.profit),
                 "swap": float(p.swap), "magic": int(p.magic)} for p in rows]

def filling_policy(info):
    # MT5 symbol filling_mode is a capability bitmask, not the order enum itself.
    if info.filling_mode & getattr(mt5, "SYMBOL_FILLING_IOC", 2):
        return mt5.ORDER_FILLING_IOC
    if info.filling_mode & getattr(mt5, "SYMBOL_FILLING_FOK", 1):
        return mt5.ORDER_FILLING_FOK
    return mt5.ORDER_FILLING_RETURN

def send_market_order(symbol, side, volume):
    account = account_snapshot()
    terminal = mt5.terminal_info()
    if not bool(account.trade_allowed) or terminal is None or not bool(terminal.trade_allowed):
        raise RuntimeError("Trading is disabled in MT5 terminal/account settings")
    info = mt5.symbol_info(symbol)
    if info is None:
        raise RuntimeError(f"Symbol unavailable: {symbol}")
    if not info.visible and not mt5.symbol_select(symbol, True):
        raise RuntimeError(f"Could not select symbol {symbol}")
    tick = mt5.symbol_info_tick(symbol)
    if tick is None:
        raise RuntimeError(f"No tick for {symbol}")
    step = float(info.volume_step or 0.01)
    if volume < float(info.volume_min) or volume > float(info.volume_max) or abs((volume / step) - round(volume / step)) > 1e-7:
        raise RuntimeError(f"Lot {volume} is invalid for {symbol}; broker min/max/step are {info.volume_min}/{info.volume_max}/{step}")
    order_type = mt5.ORDER_TYPE_BUY if side == "BUY" else mt5.ORDER_TYPE_SELL
    price = tick.ask if side == "BUY" else tick.bid
    request = {"action": mt5.TRADE_ACTION_DEAL, "symbol": symbol, "volume": float(volume),
               "type": order_type, "price": price, "deviation": 20, "magic": 7261107,
               "comment": "GridBot MT5", "type_time": mt5.ORDER_TIME_GTC,
               "type_filling": filling_policy(info)}
    result = mt5.order_send(request)
    if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
        raise RuntimeError(f"Order rejected: {getattr(result, 'comment', mt5.last_error())}")
    return {"ticket": int(result.order), "deal": int(result.deal), "price": float(result.price),
            "volume": float(volume), "side": side, "retcode": int(result.retcode)}

def close_positions_with_confirmation(symbol=None, attempts=3):
    last_remaining = []
    for _ in range(attempts):
        rows = mt5.positions_get(symbol=symbol) if symbol else mt5.positions_get()
        if rows is None:
            raise RuntimeError(f"MT5 positions_get failed during close confirmation: {mt5.last_error()}")
        rows = [p for p in rows if int(p.magic) == 7261107]
        if not rows:
            return []
        last_remaining = rows
        for position in list(rows):
            close_position(position)
        time.sleep(0.5)
    rows = mt5.positions_get(symbol=symbol) if symbol else mt5.positions_get()
    if rows is None:
        raise RuntimeError(f"MT5 positions_get failed during final close confirmation: {mt5.last_error()}")
    return [p for p in rows if int(p.magic) == 7261107]

def close_position(p):
    tick = mt5.symbol_info_tick(p.symbol)
    info = mt5.symbol_info(p.symbol)
    if tick is None or info is None: raise RuntimeError(f"No quote/specification for {p.symbol}")
    is_buy = p.type == mt5.POSITION_TYPE_BUY
    request = {"action": mt5.TRADE_ACTION_DEAL, "symbol": p.symbol, "volume": float(p.volume),
               "type": mt5.ORDER_TYPE_SELL if is_buy else mt5.ORDER_TYPE_BUY,
               "position": int(p.ticket), "price": float(tick.bid if is_buy else tick.ask),
               "deviation": 20, "magic": 7261107, "comment": "GridBot close",
               "type_time": mt5.ORDER_TIME_GTC,
               "type_filling": filling_policy(info)}
    result = mt5.order_send(request)
    if result is None or result.retcode != mt5.TRADE_RETCODE_DONE:
        raise RuntimeError(f"Close failed for {p.ticket}: {getattr(result, 'comment', mt5.last_error())}")

@app.post("/api/start", dependencies=[Depends(auth)])
def start(req: StartRequest):
    global worker
    mt5_ready()
    if bot_state["running"] or (worker is not None and worker.is_alive()):
        raise HTTPException(409, "Robot is running or still stopping; wait before starting again")
    info = account_snapshot()
    mode = int(getattr(info, "trade_mode", -1))
    is_demo = mode == 0
    if req.demo_only and not is_demo:
        raise HTTPException(403, "This configuration is Demo-only. Connect a Demo account first.")
    if not is_demo and (not ALLOW_LIVE or (REQUIRE_LIVE_CONFIRMATION and not req.live_confirmed)):
        raise HTTPException(403, "Live trading is locked. Demo-test first; server live switches and explicit confirmation are required.")
    if int(info.margin_mode) != int(mt5.ACCOUNT_MARGIN_MODE_RETAIL_HEDGING):
        raise HTTPException(409, "This grid strategy requires an MT5 hedging account; netting accounts are not supported.")
    if not mt5.symbol_select(req.symbol, True):
        raise HTTPException(400, f"Cannot select symbol {req.symbol}: {mt5.last_error()}")
    stop_event.clear()
    bot_state.update({"running": True, "mode": "DEMO" if is_demo else "LIVE", "message": "Starting 10-second momentum strategy"})
    worker = threading.Thread(target=run_bot, args=(req,), daemon=True, name="GridBotStrategy")
    worker.start()
    return {"started": True, "mode": bot_state["mode"], "symbol": req.symbol,
            "signal_window_seconds": 10, "cooldown_after_basket_close_seconds": 10,
            "lots": list(LOTS), "emergency_loss_usd": 50.0}

def run_bot(cfg):
    state = GridState(cfg.step_price)
    last_sample = None
    basket_closed_at = 0.0
    while not stop_event.is_set():
        try:
            with lock:
                tick = mt5.symbol_info_tick(cfg.symbol)
                if tick is None: raise RuntimeError(f"No market tick: {mt5.last_error()}")
                mid = (float(tick.bid) + float(tick.ask)) / 2.0
                now = time.monotonic()
                if last_sample is None:
                    last_sample = (now, mid)
                    time.sleep(0.25); continue
                elapsed = now - last_sample[0]
                positions_now = mt5.positions_get(symbol=cfg.symbol)
                if positions_now is None:
                    raise RuntimeError(f"MT5 positions_get failed: {mt5.last_error()}")
                # Only this bot's magic number is managed.
                positions_now = [p for p in positions_now if int(p.magic) == 7261107]
                positions_now.sort(key=lambda p: int(getattr(p, "time_msc", p.time)))
                pnl = sum(float(p.profit) + float(p.swap) for p in positions_now)
                if state.halted:
                    bot_state.update({"running": False, "message": "Emergency stop latched; manual operator restart required"})
                    stop_event.set()
                    break
                if not positions_now:
                    if state.side is not None:
                        state.reset(); basket_closed_at = now; last_sample = (now, mid)
                        bot_state.update({"last_action": "BASKET_CLOSED", "message": "Basket closed; cooldown-window 10-second movement selects next direction"})
                    if now - basket_closed_at < 10:
                        time.sleep(0.25); continue
                    if elapsed >= 10:
                        delta = mid - last_sample[1]
                        last_sample = (now, mid)
                        side = momentum_side(delta, cfg.signal_min_move)
                        if side is not None:
                            result = send_market_order(cfg.symbol, side, LOTS[0])
                            state.side = side; state.last_entry = float(result["price"])
                            bot_state.update({"last_signal": side, "last_action": result,
                                              "message": f"Opened first {side} 0.01 lot from 10-second movement"})
                    else:
                        time.sleep(0.2)
                    continue
                # Keep existing basket direction; do not reverse inside an open basket.
                side = "BUY" if positions_now[0].type == mt5.POSITION_TYPE_BUY else "SELL"
                state.side = side
                if state.last_entry is None: state.last_entry = float(positions_now[-1].price_open)
                decision = state.decide(side, float(tick.bid), float(tick.ask), positions_now, pnl)
                if decision.action == "CLOSE_ALL":
                    remaining = close_positions_with_confirmation(cfg.symbol, attempts=3)
                    # Confirm closure before cooldown/new basket.
                    if not remaining:
                        was_halted = state.halted
                        state.reset(); basket_closed_at = time.monotonic(); last_sample = (basket_closed_at, mid)
                        bot_state.update({"last_action": "CLOSE_ALL", "message": decision.reason + ("; emergency halt active" if was_halted else "; cooldown-window 10-second movement selects next direction")})
                        if was_halted:
                            stop_event.set()
                    elif state.halted:
                        bot_state.update({"last_error": "Emergency close was not fully confirmed; remaining positions need manual attention", "message": "Emergency stop latched with remaining positions"})
                        stop_event.set()
                elif decision.action == "OPEN":
                    result = send_market_order(cfg.symbol, decision.side, decision.volume)
                    state.last_entry = float(result["price"])
                    bot_state.update({"last_action": result, "message": decision.reason})
                time.sleep(0.25)
        except Exception as exc:
            log.exception("strategy worker error")
            bot_state.update({"last_error": str(exc), "message": "Strategy stopped after execution error"})
            stop_event.set()
    bot_state["running"] = False

@app.post("/api/stop", dependencies=[Depends(auth)])
def stop():
    stop_event.set()
    active_worker = worker
    if active_worker is not None and active_worker.is_alive():
        active_worker.join(timeout=8)
        if active_worker.is_alive():
            raise HTTPException(409, "Strategy worker has not stopped yet; retry stop")
    bot_state.update({"running": False, "message": "Stopped; existing positions were NOT force-closed"})
    return {"stopped": True, "positions_closed": False, "note": "Stop prevents new actions; existing positions remain open."}

@app.post("/api/close-all", dependencies=[Depends(auth)])
def close_all():
    mt5_ready()
    stop_event.set()
    bot_state.update({"running": False, "message": "Stopping strategy before close-all"})
    active_worker = worker
    if active_worker is not None and active_worker.is_alive():
        active_worker.join(timeout=8)
        if active_worker.is_alive():
            raise HTTPException(409, "Strategy worker has not stopped yet; retry close-all")
    with lock:
        remaining = close_positions_with_confirmation(attempts=3)
        return {"remaining_positions": len(remaining),
                "closed": len(remaining) == 0,
                "message": "All GridBot positions confirmed closed" if not remaining else "Some positions remain; inspect MT5 terminal and close manually"}

@app.post("/api/disconnect", dependencies=[Depends(auth)])
def disconnect():
    global connected
    if bot_state["running"] or (worker is not None and worker.is_alive()): raise HTTPException(409, "Stop robot and wait for worker exit first")
    with lock:
        mt5.shutdown(); connected = False
    return {"connected": False}
