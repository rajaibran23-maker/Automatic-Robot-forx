@echo off
cd /d %~dp0
if not exist .venv (
  py -3.11 -m venv .venv 2>nul
  if errorlevel 1 python -m venv .venv
)
call .venv\Scripts\activate.bat
python -m pip install --upgrade pip
pip install -r requirements.txt
if not exist .env copy .env.example .env
echo.
echo IMPORTANT: Edit .env and replace GRIDBOT_API_KEY with a random secret (24+ characters).
echo Set MT5_TERMINAL_PATH to the exact terminal64.exe path.
pause
uvicorn server:app --env-file .env --host 127.0.0.1 --port 8765
