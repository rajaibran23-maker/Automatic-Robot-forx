"""Pure GridBot strategy logic. No broker calls are made from this module."""
from dataclasses import dataclass
from typing import Optional

LOTS = (0.01, 0.02, 0.03, 0.05)

def momentum_side(price_delta: float, minimum_move: float = 0.0):
    """Direction from a completed 10-second mid-price sample; None means wait."""
    if abs(float(price_delta)) < float(minimum_move) or float(price_delta) == 0:
        return None
    return "BUY" if price_delta > 0 else "SELL"

@dataclass
class Decision:
    action: str
    side: Optional[str] = None
    volume: Optional[float] = None
    reason: str = ""

class GridState:
    def __init__(self, step_price: float, first_target: float = 1.0,
                 final_target: float = 3.0, emergency_loss: float = 50.0):
        if step_price <= 0:
            raise ValueError("step_price must be > 0")
        self.step = step_price
        self.first_target = first_target
        self.final_target = final_target
        self.emergency_loss = emergency_loss
        self.side = None
        self.last_entry = None
        self.halted = False

    def reset(self):
        self.side = None
        self.last_entry = None

    def decide(self, side, bid, ask, positions, basket_pnl):
        if self.halted:
            return Decision("HOLD", reason="Emergency stop latched; manual reset required")
        if basket_pnl <= -self.emergency_loss:
            self.halted = True
            return Decision("CLOSE_ALL", reason=f"Emergency loss reached -${self.emergency_loss:.2f}")
        if positions:
            lots_open = [float(p.volume) for p in positions]
            target = self.final_target if any(v >= 0.05 - 1e-8 for v in lots_open) else self.first_target
            if basket_pnl >= target:
                return Decision("CLOSE_ALL", reason=f"Basket target reached +${target:.2f}")
            if self.side and side != self.side:
                return Decision("HOLD", reason="Direction changed; existing basket side is kept")
            if self.last_entry is None:
                self.last_entry = float(positions[-1].price_open)
            level = len(positions)
            if level >= len(LOTS):
                return Decision("HOLD", reason="All four grid levels are open")
            distance = self.step * (2.0 if level == 3 else 1.0)
            adverse = (self.last_entry - bid) if self.side == "BUY" else (ask - self.last_entry)
            if adverse >= distance:
                vol = LOTS[level]
                self.last_entry = ask if self.side == "BUY" else bid
                return Decision("OPEN", self.side, vol, f"Grid level {level + 1}")
            return Decision("HOLD", reason="Waiting for configured adverse grid distance")
        return Decision("SIGNAL_REQUIRED", reason="Wait for a fresh 10-second momentum signal")
